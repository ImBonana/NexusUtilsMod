package dev.emi.trinkets.compat;

import dev.emi.trinkets.TrinketPlayerScreenHandler;
import dev.emi.trinkets.TrinketScreen;
import dev.emi.trinkets.TrinketScreenManager;
import dev.emi.trinkets.TrinketsClient;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_437;
import net.minecraft.class_481;
import net.minecraft.class_768;

public class TrinketsExclusionAreas {

	public static List<class_768> create(class_437 screen) {
		if (screen instanceof TrinketScreen trinketScreen) {
			if (screen instanceof class_481 creativeInventoryScreen &&
				!creativeInventoryScreen.method_47424()) {
				return List.of();
			}
			List<class_768> rects = new ArrayList<>();
			int x = trinketScreen.trinkets$getX();
			int y = trinketScreen.trinkets$getY();
			TrinketPlayerScreenHandler handler = trinketScreen.trinkets$getHandler();
			int groupCount = handler.trinkets$getGroupCount();
			if (groupCount <= 0 || trinketScreen.trinkets$isRecipeBookOpen()) {
				return List.of();
			}

			if (TrinketsClient.activeGroup != null) {
				class_768 rect = TrinketScreenManager.currentBounds;
				rects.add(
					new class_768(rect.method_3321() + x, rect.method_3322() + y, rect.method_3319(),
						rect.method_3320()));
			}
			int width = groupCount / 4;
			int height = groupCount % 4;
			if (width > 0) {
				rects.add(new class_768(-4 - 18 * width + x, y, 7 + 18 * width, 86));
			}

			if (height > 0) {
				rects.add(new class_768(-22 - 18 * width + x, y, 25, 14 + 18 * height));
			}
			return rects;
		}
		return List.of();
	}
}

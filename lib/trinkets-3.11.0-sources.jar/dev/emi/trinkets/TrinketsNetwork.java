package dev.emi.trinkets;

import dev.emi.trinkets.payload.BreakPayload;
import dev.emi.trinkets.payload.SyncInventoryPayload;
import dev.emi.trinkets.payload.SyncSlotsPayload;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

public class TrinketsNetwork {

  public static final class_8710.class_9154<SyncSlotsPayload> SYNC_SLOTS = new class_8710.class_9154<>(class_2960.method_60655(TrinketsMain.MOD_ID, "sync_slots"));
  public static final class_8710.class_9154<SyncInventoryPayload> SYNC_INVENTORY = new class_8710.class_9154<>(class_2960.method_60655(TrinketsMain.MOD_ID, "sync_inventory"));
  public static final class_8710.class_9154<BreakPayload> BREAK = new class_8710.class_9154<>(class_2960.method_60655(TrinketsMain.MOD_ID, "break"));

  private TrinketsNetwork() {
  }
}

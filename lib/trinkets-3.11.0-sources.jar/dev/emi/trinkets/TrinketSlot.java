package dev.emi.trinkets;

import dev.emi.trinkets.api.SlotReference;
import dev.emi.trinkets.api.SlotType;
import dev.emi.trinkets.api.TrinketsApi;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2960;

public interface TrinketSlot {

	public boolean isTrinketFocused();

	public class_2960 getBackgroundIdentifier();

	public SlotType getType();
	
	public static boolean canInsert(class_1799 stack, SlotReference slotRef, class_1309 entity) {
		boolean res = TrinketsApi.evaluatePredicateSet(slotRef.inventory().getSlotType().getValidatorPredicates(),
			stack, slotRef, entity);

		if (res) {
			return TrinketsApi.getTrinket(stack.method_7909()).canEquip(stack, slotRef, entity);
		}

		return false;
	}
}

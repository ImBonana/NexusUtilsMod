package dev.emi.trinkets;

import dev.emi.trinkets.api.SlotGroup;
import net.minecraft.class_1735;
import net.minecraft.class_768;

public interface TrinketScreen {

	public TrinketPlayerScreenHandler trinkets$getHandler();

	public class_768 trinkets$getGroupRect(SlotGroup group);

	public class_1735 trinkets$getFocusedSlot();
	
	public int trinkets$getX();
	
	public int trinkets$getY();

	public default boolean trinkets$isRecipeBookOpen() {
		return false;
	}

	public default void trinkets$updateTrinketSlots() {
	}
}

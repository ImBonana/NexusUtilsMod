package dev.emi.trinkets.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.emi.trinkets.TrinketScreenManager;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import dev.emi.trinkets.TrinketSlot;
import dev.emi.trinkets.TrinketsClient;
import dev.emi.trinkets.mixin.accessor.CreativeSlotAccessor;
import java.util.function.Function;
import net.minecraft.class_1735;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_481.class_484;
import net.minecraft.class_490;

/**
 * Draws trinket slot backs, adjusts z location of draw calls, and makes non-trinket slots un-interactable while a trinket slot group is focused
 * 
 * @author Emi
 */
@Mixin(class_465.class)
public abstract class HandledScreenMixin extends class_437 {
	@Shadow @Nullable protected class_1735 focusedSlot;
	@Shadow @Final private static class_2960 SLOT_HIGHLIGHT_BACK_TEXTURE;
	@Unique
	private static final class_2960 MORE_SLOTS = class_2960.method_60655("trinkets", "textures/gui/more_slots.png");
	@Unique
	private static final class_2960 BLANK_BACK = class_2960.method_60655("trinkets", "textures/gui/blank_back.png");

	private HandledScreenMixin() {
		super(null);
	}

	@Inject(at = @At("HEAD"), method = "removed")
	private void removed(CallbackInfo info) {
		if ((Object)this instanceof class_490) {
			TrinketScreenManager.removeSelections();
		}
	}

	@Inject(at = @At(value = "INVOKE", target = "net/minecraft/client/util/math/MatrixStack.translate(FFF)V"),
		method = "drawSlot")
	private void changeZ(class_332 context, class_1735 slot, CallbackInfo info) {
		// Items are drawn at z + 150 (normal items are drawn at 250)
		// Item tooltips (count, item bar) are drawn at z + 200 (normal itmes are drawn at 300)
		// Inventory tooltip is drawn at 400
		if (slot instanceof TrinketSlot ts) {
			assert this.field_22787 != null;
			class_2960 slotTextureId = ts.getBackgroundIdentifier();

			if (!slot.method_7677().method_7960() || slotTextureId == null) {
				slotTextureId = BLANK_BACK;
			}

			if (ts.isTrinketFocused()) {
				// Thus, I need to draw trinket slot backs over normal items at z 300 (310 was chosen)
				context.method_51448().method_46416(0, 0, 310);
				context.method_25290(class_1921::method_62277, slotTextureId, slot.field_7873, slot.field_7872, 0, 0, 16, 16, 16, 16);
				if (this.focusedSlot == slot && this.focusedSlot.method_51306()) {
					context.method_52706(class_1921::method_62277, SLOT_HIGHLIGHT_BACK_TEXTURE, this.focusedSlot.field_7873 - 4, this.focusedSlot.field_7872 - 4, 24, 24);
				}
				context.method_51448().method_46416(0, 0, -310);
				// I also need to draw items in trinket slots *above* 310 but *below* 400, (320 for items and 370 for tooltips was chosen)
				context.method_51448().method_46416(0, 0, 70);
			} else {
				context.method_25290(class_1921::method_62277, slotTextureId, slot.field_7873, slot.field_7872, 0, 0, 16, 16, 16, 16);
				context.method_25290(class_1921::method_62277, MORE_SLOTS, slot.field_7873 - 1, slot.field_7872 - 1, 4, 4, 18, 18, 256, 256);
			}
		}
	}

	@WrapOperation(method = "drawSlotHighlightFront", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Ljava/util/function/Function;Lnet/minecraft/util/Identifier;IIII)V"))
	private void changeZForHighlightFront(class_332 context, Function<class_2960, class_1921> renderLayers, class_2960 sprite, int x, int y, int width, int height, Operation<Void> original) {
		assert this.focusedSlot != null;
		if (this.focusedSlot instanceof TrinketSlot) {
			context.method_51448().method_22903();
			context.method_51448().method_46416(0, 0, 100 + 310 + 70 + 70 + 1);
			original.call(context, renderLayers, sprite, x, y, width, height);
			context.method_51448().method_22909();
		} else if (this.focusedSlot instanceof TrinketSlot) {
			context.method_51448().method_22903();
			context.method_51448().method_46416(0, 0, 100 + 310 + 70 + 70 + 1);
			original.call(context, renderLayers, sprite, x, y, width, height);
			context.method_51448().method_22909();
		} else {
			original.call(context, renderLayers, sprite, x, y, width, height);
		}
	}

	@Inject(at = @At("HEAD"), method = "isPointOverSlot", cancellable = true)
	private void isPointOverSlot(class_1735 slot, double pointX, double pointY, CallbackInfoReturnable<Boolean> info) {
		if (TrinketsClient.activeGroup != null) {
			if (slot instanceof TrinketSlot ts) {
				if (!ts.isTrinketFocused()) {
					info.setReturnValue(false);
				}
			} else {
				if (slot instanceof class_484 cs) {
					if (((CreativeSlotAccessor) cs).getSlot().field_7874 != TrinketsClient.activeGroup.getSlotId()) {
						info.setReturnValue(false);
					}
				} else if (slot.field_7874 != TrinketsClient.activeGroup.getSlotId()) {
					info.setReturnValue(false);
				}
			}
		}
	}
}

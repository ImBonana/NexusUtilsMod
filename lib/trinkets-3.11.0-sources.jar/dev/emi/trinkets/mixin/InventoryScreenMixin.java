package dev.emi.trinkets.mixin;

import dev.emi.trinkets.mixin.accessor.RecipeBookScreenAccessor;
import net.minecraft.class_10260;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_332;
import net.minecraft.class_490;
import net.minecraft.class_518;
import net.minecraft.class_768;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.emi.trinkets.Point;
import dev.emi.trinkets.TrinketPlayerScreenHandler;
import dev.emi.trinkets.TrinketScreen;
import dev.emi.trinkets.TrinketScreenManager;
import dev.emi.trinkets.api.SlotGroup;

/**
 * Delegates drawing and slot group selection logic
 * 
 * @author Emi
 */
@Mixin(class_490.class)
public abstract class InventoryScreenMixin extends class_10260<class_1723> implements class_518, TrinketScreen {
	public InventoryScreenMixin() {
		super(null, null, null, null);
	}

	@Inject(at = @At("HEAD"), method = "init")
	private void init(CallbackInfo info) {
		TrinketScreenManager.init(this);
	}

	@Inject(at = @At("TAIL"), method = "handledScreenTick")
	private void tick(CallbackInfo info) {
		TrinketScreenManager.tick();
	}

	@Inject(at = @At("HEAD"), method = "render")
	private void render(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
		TrinketScreenManager.update(mouseX, mouseY);
	}

	@Inject(at = @At("RETURN"), method = "drawBackground")
	private void drawBackground(class_332 context, float delta, int mouseX, int mouseY, CallbackInfo info) {
		TrinketScreenManager.drawExtraGroups(context);
	}

	@Inject(at = @At("TAIL"), method = "drawForeground")
	private void drawForeground(class_332 context, int mouseX, int mouseY, CallbackInfo info) {
		TrinketScreenManager.drawActiveGroup(context);
	}


	@Override
	public TrinketPlayerScreenHandler trinkets$getHandler() {
		return (TrinketPlayerScreenHandler) this.field_2797;
	}
	
	@Override
	public class_768 trinkets$getGroupRect(SlotGroup group) {
		Point pos = ((TrinketPlayerScreenHandler) field_2797).trinkets$getGroupPos(group);
		if (pos != null) {
			return new class_768(pos.x() - 1, pos.y() - 1, 17, 17);
		}
		return new class_768(0, 0, 0, 0);
	}

	@Override
	public class_1735 trinkets$getFocusedSlot() {
		return this.field_2787;
	}

	@Override
	public int trinkets$getX() {
		return this.field_2776;
	}

	@Override
	public int trinkets$getY() {
		return this.field_2800;
	}

	@Override
	public boolean trinkets$isRecipeBookOpen() {
		return ((RecipeBookScreenAccessor) this).getRecipeBook().method_2605();
	}
}

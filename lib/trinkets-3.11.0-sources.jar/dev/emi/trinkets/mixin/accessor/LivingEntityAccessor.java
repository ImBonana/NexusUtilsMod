package dev.emi.trinkets.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

@Environment(EnvType.CLIENT)
@Mixin(class_1309.class)
public interface LivingEntityAccessor {
	
	@Invoker("playEquipmentBreakEffects")
	public void invokePlayEquipmentBreakEffects(class_1799 stack);
}

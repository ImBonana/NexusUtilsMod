package dev.emi.trinkets.mixin.accessor;

import net.minecraft.class_10260;
import net.minecraft.class_507;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_10260.class)
public interface RecipeBookScreenAccessor {
    @Accessor
    class_507<?> getRecipeBook();
}

package dev.emi.trinkets.mixin;

import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

/**
 * Allows mutation of trinket slots (and all other valid slots) in the creative inventory
 * 
 * @author Emi
 */
@Mixin(class_3244.class)
public class ServerPlayNetworkHandlerMixin {
	@Shadow
	public class_3222 player;
	
	@ModifyConstant(method = "onCreativeInventoryAction", constant = @Constant(intValue = 45))
	public int modifyCreativeSlotMax(int value) {
		return player.field_7498.field_7761.size();
	}
}

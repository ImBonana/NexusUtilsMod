package dev.emi.trinkets;

import dev.emi.trinkets.api.SlotReference;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_3545;

public interface TrinketEntityRenderState {
    void trinkets$setState(List<class_3545<class_1799, SlotReference>> items);
    List<class_3545<class_1799, SlotReference>> trinkets$getState();
}

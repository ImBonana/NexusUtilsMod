package dev.emi.trinkets.api;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.Predicate;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3545;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;

import dev.emi.trinkets.TrinketModifiers;
import dev.emi.trinkets.TrinketPlayerScreenHandler;
import org.ladysnake.cca.api.v3.component.sync.AutoSyncedComponent;
import org.ladysnake.cca.api.v3.entity.RespawnableComponent;

public class LivingEntityTrinketComponent implements TrinketComponent, AutoSyncedComponent, RespawnableComponent {

	public Map<String, Map<String, TrinketInventory>> inventory = new HashMap<>();
	public Set<TrinketInventory> trackingUpdates = new HashSet<>();
	public Map<String, SlotGroup> groups = new HashMap<>();
	public int size;
	public class_1309 entity;
	private boolean syncing;

	public LivingEntityTrinketComponent(class_1309 entity) {
		this.entity = entity;
		this.update();
	}

	@Override
	public class_1309 getEntity() {
		return this.entity;
	}

	@Override
	public Map<String, SlotGroup> getGroups() {
		return this.groups;
	}

	@Override
	public Map<String, Map<String, TrinketInventory>> getInventory() {
		return inventory;
	}

	@Override
	public void update() {
		Map<String, SlotGroup> entitySlots = TrinketsApi.getEntitySlots(this.entity);
		int count = 0;
		groups.clear();
		Map<String, Map<String, TrinketInventory>> inventory = new HashMap<>();
		for (Map.Entry<String, SlotGroup> group : entitySlots.entrySet()) {
			String groupKey = group.getKey();
			SlotGroup groupValue = group.getValue();
			Map<String, TrinketInventory> oldGroup = this.inventory.get(groupKey);
			groups.put(groupKey, groupValue);
			for (Map.Entry<String, SlotType> slot : groupValue.getSlots().entrySet()) {
				TrinketInventory inv = new TrinketInventory(slot.getValue(), this, e -> this.trackingUpdates.add(e));
				if (oldGroup != null) {
					TrinketInventory oldInv = oldGroup.get(slot.getKey());
					if (oldInv != null) {
						inv.copyFrom(oldInv);
						for (int i = 0; i < oldInv.method_5439(); i++) {
							class_1799 stack = oldInv.method_5438(i).method_7972();
							if (i < inv.method_5439()) {
								inv.method_5447(i, stack);
							} else {
								if (this.entity instanceof class_1657 player) {
									player.method_31548().method_7398(stack);
								} else if (this.entity.method_37908() instanceof class_3218 serverWorld) {
									this.entity.method_5775(serverWorld, stack);
								}
							}
						}
					}
				}
				inventory.computeIfAbsent(group.getKey(), (k) -> new HashMap<>()).put(slot.getKey(), inv);
				count += inv.method_5439();
			}
		}
		size = count;
		this.inventory = inventory;
	}

	@Override
	public void clearCachedModifiers() {
		for (Map.Entry<String, Map<String, TrinketInventory>> group : this.getInventory().entrySet()) {
			for (Map.Entry<String, TrinketInventory> slotType : group.getValue().entrySet()) {
				slotType.getValue().clearCachedModifiers();
			}
		}
	}

	@Override
	public Set<TrinketInventory> getTrackingUpdates() {
		return this.trackingUpdates;
	}

	@Override
	public void addTemporaryModifiers(Multimap<String, class_1322> modifiers) {
		for (Map.Entry<String, Collection<class_1322>> entry : modifiers.asMap().entrySet()) {
			String[] keys = entry.getKey().split("/");
			String group = keys[0];
			String slot = keys[1];
			for (class_1322 modifier : entry.getValue()) {
				Map<String, TrinketInventory> groupInv = this.inventory.get(group);
				if (groupInv != null) {
					TrinketInventory inv = groupInv.get(slot);
					if (inv != null) {
						inv.addModifier(modifier);
					}
				}
			}
		}
	}

	@Override
	public void addPersistentModifiers(Multimap<String, class_1322> modifiers) {
		for (Map.Entry<String, Collection<class_1322>> entry : modifiers.asMap().entrySet()) {
			String[] keys = entry.getKey().split("/");
			String group = keys[0];
			String slot = keys[1];
			for (class_1322 modifier : entry.getValue()) {
				Map<String, TrinketInventory> groupInv = this.inventory.get(group);
				if (groupInv != null) {
					TrinketInventory inv = groupInv.get(slot);
					if (inv != null) {
						inv.addPersistentModifier(modifier);
					}
				}
			}
		}
	}

	@Override
	public void removeModifiers(Multimap<String, class_1322> modifiers) {
		for (Map.Entry<String, Collection<class_1322>> entry : modifiers.asMap().entrySet()) {
			String[] keys = entry.getKey().split("/");
			String group = keys[0];
			String slot = keys[1];
			for (class_1322 modifier : entry.getValue()) {
				Map<String, TrinketInventory> groupInv = this.inventory.get(group);
				if (groupInv != null) {
					TrinketInventory inv = groupInv.get(slot);
					if (inv != null) {
						inv.removeModifier(modifier.comp_2447());
					}
				}
			}
		}
	}

	@Override
	public Multimap<String, class_1322> getModifiers() {
		Multimap<String, class_1322> result = HashMultimap.create();
		for (Map.Entry<String, Map<String, TrinketInventory>> group : this.getInventory().entrySet()) {
			for (Map.Entry<String, TrinketInventory> slotType : group.getValue().entrySet()) {
				result.putAll(group.getKey() + "/" + slotType.getKey(), slotType.getValue().getModifiers().values());
			}
		}

		return result;
	}

	@Override
	public void clearModifiers() {
		for (Map.Entry<String, Map<String, TrinketInventory>> group : this.getInventory().entrySet()) {
			for (Map.Entry<String, TrinketInventory> slotType : group.getValue().entrySet()) {
				slotType.getValue().clearModifiers();
			}
		}
	}

	@Override
	public void readFromNbt(class_2487 tag, class_7225.class_7874 lookup) {
		class_2371<class_1799> dropped = class_2371.method_10211();
		for (String groupKey : tag.method_10541()) {
			class_2487 groupTag = tag.method_10562(groupKey);
			if (groupTag != null) {
				Map<String, TrinketInventory> groupSlots = this.inventory.get(groupKey);
				if (groupSlots != null) {
					for (String slotKey : groupTag.method_10541()) {
						class_2487 slotTag = groupTag.method_10562(slotKey);
						class_2499 list = slotTag.method_10554("Items", class_2520.field_33260);
						TrinketInventory inv = groupSlots.get(slotKey);

						if (inv != null) {
							inv.fromTag(slotTag.method_10562("Metadata"));
						}

						for (int i = 0; i < list.size(); i++) {
							class_2487 c = list.method_10602(i);
							class_1799 stack = class_1799.method_57359(lookup, c);
							if (inv != null && i < inv.method_5439()) {
								inv.method_5447(i, stack);
							} else {
								dropped.add(stack);
							}
						}
					}
				} else {
					for (String slotKey : groupTag.method_10541()) {
						class_2487 slotTag = groupTag.method_10562(slotKey);
						class_2499 list = slotTag.method_10554("Items", class_2520.field_33260);
						for (int i = 0; i < list.size(); i++) {
							class_2487 c = list.method_10602(i);
							dropped.add(class_1799.method_57359(lookup, c));
						}
					}
				}
			}
		}
		if (this.entity.method_37908() instanceof class_3218 serverWorld) {
			for (class_1799 itemStack : dropped) {
				this.entity.method_5775(serverWorld, itemStack);
			}
		}
		Multimap<String, class_1322> slotMap = HashMultimap.create();
		this.forEach((ref, stack) -> {
			if (!stack.method_7960()) {
				Multimap<class_6880<class_1320>, class_1322> map = TrinketModifiers.get(stack, ref, entity);
				for (class_6880<class_1320> entityAttribute : map.keySet()) {
					if (entityAttribute.method_40227() && entityAttribute.comp_349() instanceof SlotAttributes.SlotEntityAttribute slotEntityAttribute) {
						slotMap.putAll(slotEntityAttribute.slot, map.get(entityAttribute));
					}
				}
			}
		});
		for (Map.Entry<String, Map<String, TrinketInventory>> groupEntry : this.getInventory().entrySet()) {
			for (Map.Entry<String, TrinketInventory> slotEntry : groupEntry.getValue().entrySet()) {
				String group = groupEntry.getKey();
				String slot = slotEntry.getKey();
				String key = group + "/" + slot;
				Collection<class_1322> modifiers = slotMap.get(key);
				TrinketInventory inventory = slotEntry.getValue();
				for (class_1322 modifier : modifiers) {
					inventory.removeCachedModifier(modifier);
				}
				inventory.clearCachedModifiers();
			}
		}
	}

	@Override
	public void applySyncPacket(class_9129 buf) {
		class_2487 tag = buf.method_10798();

		if (tag != null) {

			for (String groupKey : tag.method_10541()) {
				class_2487 groupTag = tag.method_10562(groupKey);

				if (groupTag != null) {
					Map<String, TrinketInventory> groupSlots = this.inventory.get(groupKey);

					if (groupSlots != null) {

						for (String slotKey : groupTag.method_10541()) {
							class_2487 slotTag = groupTag.method_10562(slotKey);
							class_2499 list = slotTag.method_10554("Items", class_2520.field_33260);
							TrinketInventory inv = groupSlots.get(slotKey);

							if (inv != null) {
								inv.applySyncTag(slotTag.method_10562("Metadata"));
							}

							for (int i = 0; i < list.size(); i++) {
								class_2487 c = list.method_10602(i);
								class_1799 stack = class_1799.method_57359(buf.method_56349(), c);
								if (inv != null && i < inv.method_5439()) {
									inv.method_5447(i, stack);
								}
							}
						}
					}
				}
			}

			if (this.entity instanceof class_1657 player) {
				((TrinketPlayerScreenHandler) player.field_7498).trinkets$updateTrinketSlots(false);
			}
		}
	}

	@Override
	public void writeToNbt(class_2487 tag, class_7225.class_7874 lookup) {
		for (Map.Entry<String, Map<String, TrinketInventory>> group : this.getInventory().entrySet()) {
			class_2487 groupTag = new class_2487();
			for (Map.Entry<String, TrinketInventory> slot : group.getValue().entrySet()) {
				class_2487 slotTag = new class_2487();
				class_2499 list = new class_2499();
				TrinketInventory inv = slot.getValue();
				for (int i = 0; i < inv.method_5439(); i++) {
					class_2487 c = (class_2487) inv.method_5438(i).method_57375(lookup);
					list.add(c);
				}
				slotTag.method_10566("Metadata", this.syncing ? inv.getSyncTag() : inv.toTag());
				slotTag.method_10566("Items", list);
				groupTag.method_10566(slot.getKey(), slotTag);
			}
			tag.method_10566(group.getKey(), groupTag);
		}
	}

	@Override
	public void writeSyncPacket(class_9129 buf, class_3222 recipient) {
		this.syncing = true;
		class_2487 tag = new class_2487();
		this.writeToNbt(tag, buf.method_56349());
		this.syncing = false;
		buf.method_10794(tag);
	}

	@Override
	public boolean shouldCopyForRespawn(boolean lossless, boolean keepInventory, boolean sameCharacter) {
		return lossless || keepInventory;
	}

	@Override
	public boolean isEquipped(Predicate<class_1799> predicate) {
		for (Map.Entry<String, Map<String, TrinketInventory>> group : this.getInventory().entrySet()) {
			for (Map.Entry<String, TrinketInventory> slotType : group.getValue().entrySet()) {
				TrinketInventory inv = slotType.getValue();
				for (int i = 0; i < inv.method_5439(); i++) {
					if (predicate.test(inv.method_5438(i))) {
						return true;
					}
				}
			}
		}
		return false;
	}

	@Override
	public List<class_3545<SlotReference, class_1799>> getEquipped(Predicate<class_1799> predicate) {
		List<class_3545<SlotReference, class_1799>> list = new ArrayList<>();
		forEach((slotReference, itemStack) -> {
			if (predicate.test(itemStack)) {
				list.add(new class_3545<>(slotReference, itemStack));
			}
		});
		return list;
	}

	@Override
	public void forEach(BiConsumer<SlotReference, class_1799> consumer) {
		for (Map.Entry<String, Map<String, TrinketInventory>> group : this.getInventory().entrySet()) {
			for (Map.Entry<String, TrinketInventory> slotType : group.getValue().entrySet()) {
				TrinketInventory inv = slotType.getValue();
				for (int i = 0; i < inv.method_5439(); i++) {
					consumer.accept(new SlotReference(inv, i), inv.method_5438(i));
				}
			}
		}
	}
}